<?php
session_start();

$n = rand(1000, 9999);
// echo $n;
$_SESSION["CODE"] = $n;

# 制作验证码图片
// $img = imagecreatetruecolor(100, 36);
$img = imagecreatefrompng("img/bg.png");
# 设置颜色
$red = imagecolorallocate($img, 255, 0, 0);
$green = imagecolorallocate($img, 0, 102, 0);
$blue = imagecolorallocate($img, 0, 0, 255);
$white = imagecolorallocate($img, 255, 255, 255);
$black = imagecolorallocate($img, 0, 0, 0);
# 填充背景色
imagefill($img, 0, 0, $white);
# 打印验证码
$font = "C:\\Windows\\Fonts\\arial.ttf";
$text = (string)$n;
$color = [$red, $green, $blue, $black]; // shuffle(
shuffle($color);
for($i = 0; $i < strlen($text); $i++){
    $size = rand(14, 24);
    $angle = rand(-30, 30);
    $ox = $angle / 8;
    $oy = $angle / 8;
    imagettftext($img, $size, $angle, 6 + 24 * $i - $ox, 30 - $oy, $color[$i], $font, $text[$i]);
}
# 输出图片
header("Content-Type: image/jpeg");
imagejpeg($img);
# 删除内存
imagedestroy($img);