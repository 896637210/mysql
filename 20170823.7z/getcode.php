<?php
session_start();

if (isset($_SESSION["CODE"])) {
    echo $_SESSION["CODE"];
}
