<?php
require_once "dbc.php";

// 取PDO数据对象
$resp = $pdo->query("SELECT * FROM msgs WHERE pid=0 ORDER BY top DESC, sd DESC, id DESC");

// 取数据（关联数组）
$data = $resp->fetchAll(PDO::FETCH_ASSOC);

// 转换为 JSON 格式并输出（到前台）
echo json_encode($data);

/*
[
    {
        "id": 1,
        "pid": 0,
        "user": "SYSTEM",
        "title": "标题文字1",
        "msg": "你好！",
        "sd": "",
        "top": 0
    },
    {
        "id": 2,
        "pid": 0,
        "user": "SYSTEM",
        "title": "标题文字2",
        "msg": "欢迎光临！",
        "sd": "",
        "top": 0
    }
]*/