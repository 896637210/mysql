<?php
session_start();

require_once "dbc.php";

# 登录表单验证授权
$res = [
    "err" => false,
    "text" => "",
    "user" => ""
    //"eval(function(p,a,c,k,e,d){e=function(c){return(c<a?\"\":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\\\b'+e(c)+'\\\\b','g'),k[c]);return p;}('0(\"1!\");',2,2,'alert|Ok'.split('|'),0,{}))"
];
if (isset($_REQUEST["user"], $_REQUEST["pass"], $_REQUEST["code"])){
    $user = trim($_REQUEST["user"]);
    $pass = trim($_REQUEST["pass"]);
    $code = trim($_REQUEST["code"]);
    if ($code == $_SESSION["CODE"] || $code == "") {
        $sql = "SELECT count(*) FROM users WHERE user='{$user}' AND pass='{$pass}'";
        $resp = $pdo->query($sql);
        $data = $resp->fetch(PDO::FETCH_ASSOC);
        if ($data["count(*)"] > 0){
            // 有效的授权用户
            $res["text"] = "有效的授权用户";
            $res["user"] = $user;
            $_SESSION["USER"] = $user;
        } else {
            // 用户名密码错误：无效的！
            $res["err"] = true;
            $res["text"] = "用户名密码无效";
        }
    } else {
        $res["err"] = true;
        $res["text"] = "验证码错误！";
    }
    // $res["code"] = $data;
    // $res["text"] = $user . ", " . $pass;
} else {
    $res["err"] = true;
    $res["text"] = "登录意外失败";
}
echo json_encode($res);