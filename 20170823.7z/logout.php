<?php
session_start();

// 注销用户

if (isset($_SESSION["USER"])) {
    unset($_SESSION["USER"]);
}
