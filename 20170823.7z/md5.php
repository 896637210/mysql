<?php
require_once "dbc.php";

// 盐
$salt = "OracleOAEC";
// 加盐加密
$pass = md5(md5("admin888") . $salt);

// 更新数据库
$sql = "UPDATE users SET pass='{$pass}' WHERE id=1";
$resp = $pdo->exec($sql);
