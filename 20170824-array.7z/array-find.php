<?php

# 在数组里查找
# （1）数值 in_array(find_str, array[, false|true]);
# （2）键名 array_key_exists(find_str, array);

$a = ["a1" => "大全101", "c1" => "100金典", "3a" => ["A4", "蓝1"], "0" => "A"];
$b = ["A1", "b2", "23"];
$s = "a1";
// echo in_array($s, $b, true);
// echo array_key_exists($s, $a);

# 取数组的长度 count() sizeof()
echo count($a);
// echo sizeof($a);

$str = "welcome to my home!";
// echo strlen($str);
