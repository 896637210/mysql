<?php
require_once "tool.php";

# 数组的拼合 array_merge($x, $y, ...)
# 数组的拆分 array_chunk($arr, n[, false|true])
# 数组排序中的反向 array_reverse() （不会影响原数组）
# 数组的乱序 shuffle() 随机性是有限的，效果远不如 rand
$a = ["a" => 10, "A" => 1000, "Aaaa" => -1, "hello"];
msg($a);

// msg(array_reverse($a));
shuffle($a);
shuffle($a);
shuffle($a);
msg($a);

$b = [100, 200, 400, -20];
msg($b);

$c = array_merge($a, $b);
msg($c);

$d = array_chunk($c, 3);
msg($d);

$e = array_chunk($c, 3, true);
msg($e);

