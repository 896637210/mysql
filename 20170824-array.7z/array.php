<?php
require_once "tool.php";

# PHP array("key" => "value")
# array(
#    "main" => array(
#       "sub" => "value"
#    )
# )
/*
[
    "main" => "value",
    "main2" => [
        "sub" => "value",
        "sub2" => [1, 2, 3, 4]
    ]
]
*/

$a = [1, 50000, 300, 20, 4000, -100]; // 数字数组
// msg($a);
# 数组排序 sort(), rsort()
// sort($a);
// msg($a);
// rsort($a);
// msg($a);
$b = ["a" => 1, "b" => 50000, "c" => 300, 20, 4000, "d" => -100]; // 关联数组
// msg($b);
# 关联数组的排序用 asort(), arsort()
// asort($b);
// msg($b);
// arsort($b);
// msg($b);
$c = ["10" => 1, "6" => 50000, "3" => 300, 20, 4000, "12" => -100]; // 关联数组
// msg($c);
# 数组的键排序 ksort(), krsort()
// ksort($c);
// msg($c);
// krsort($c);
// msg($c);
# 数组排序方法（数组[, 排序参数]）
# 排序 sort(), rsort()
# 保留键排序 asort(), arsort()
# 以键排序 ksort(), krsort()
# 其中的参数是：
#               SORT_REGULAR      默认值，正常比较方式
#               SORT_NUMERIC      以数字进行比较的方式
#               SORT_STRING       以字符串进行比较方式
$e = [1, 12, "a12", "1A", 4, "A", "醉", -112, "啊"];
msg($e);
msg("SORT_REGULAR");
sort($e);
msg($e);
msg("SORT_NUMERIC");
sort($e, SORT_NUMERIC);
msg($e);
msg("SORT_STRING");
sort($e, SORT_STRING);
msg($e);