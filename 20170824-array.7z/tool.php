<meta charset="utf-8">
<?php
# 自定义数据输出函数（方法）
function msg($a)
{
    if (is_array($a)) {
        echo "<pre>";
        print_r($a);
        echo "</pre>";
    }
    else {
        echo "<div>$a</div>";
    }
}
# 取得当前时间戳（微秒级）
function gettime()
{
    $t = microtime();
    $a = explode(" ", $t);
    return (float)$a[1] + (float)$a[0];
}
# 取间隔时间（秒数或毫秒数）
function timeout($start, $end)
{
    $a = explode(" ", $start);
    $start = (float)$a[1] + (float)$a[0];
    $a = explode(" ", $end);
    $end = (float)$a[1] + (float)$a[0];
    $out = ($start < $end) ? $end - $start : $start - $end;
    // 输出秒数、毫秒数
    $s = floor($out);
    $ms = round( ($out - $s) * 1000000) / 1000; // 678.23300 678.233
    // xxx s xxx.xxx ms // xxx.xxx ms
    return $s ? $s . "s " . $ms . "ms" : $ms . "ms";
}
# 文件大小格式输出：Bytes, KB, MB, GB, TG
function sfmt($size)
{
    $unit = ["B", "K", "M", "G", "T"]; // 单位 1K = 1024B
    $s = $size;
    $i = 0;
    while ($s > 1024) {
        $s /= 1024;
        $i++;
    }
    return (round($s * 10) / 10) . $unit[$i];
}