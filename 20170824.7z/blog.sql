-- 本文件 SQL 脚本
-- MySQL 命令行执行 source *.sql
-- 创建数据库
CREATE DATABASE k_blog;

-- 打开数据库
use k_blog;

-- 创建用户表 users
CREATE TABLE users (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user VARCHAR(32) NOT NULL,
    pass VARCHAR(36) NOT NULL,
    sex INT NOT NULL DEFAULT 2,
    lgip VARCHAR(18) NULL,
    lgdt TIMESTAMP NULL
);
-- 插入数据
INSERT INTO users (user, pass) VALUES ('admin', 'admin888');

-- 帖子信息表
CREATE TABLE msgs (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    pid INT NOT NULL default 0,
    user VARCHAR(32) NOT NULL,
    title VARCHAR(100) NOT NULL,
    msg LONGTEXT NOT NULL,
    sd TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    top INT NOT NULL default 0
) DEFAULT CHARSET=UTF8;
-- 插入数据
INSERT INTO msgs (user, title, msg, top) VALUES ('SYSTEM', 'HELLO', 'Blog is opened now!', 1);
ALTER TABLE msgs ADD rc INT NOT NULL DEFAULT 0;