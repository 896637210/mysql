<?php
session_start();

$res = [
    "user" => "",
    "logon" => false
];

if (isset($_SESSION["USER"])) {
    $res["user"] = $_SESSION["USER"];
    $res["logon"] = true;
}

echo json_encode($res);