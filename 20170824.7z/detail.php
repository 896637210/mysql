<?php
require_once "dbc.php";

# k_blog | msgs : id, pid, user, title, msg, sd, top, rc

// 接收前台发送的帖子ID
if (!isset($_REQUEST["id"])){
    exit('{"error":true,"text":"参数错误：缺少ID"}');
}
$id = trim($_REQUEST["id"]);
// 取PDO数据对象
$sql = "SELECT * FROM msgs WHERE id={$id}";
$resp = $pdo->query($sql);

// 取数据（关联数组）
$data = $resp->fetchAll(PDO::FETCH_ASSOC);
// 阅读计数器rc +1
$rc = $data[0]["rc"] + 1;
// 更新计数器值
$pdo->exec("UPDATE msgs SET rc={$rc} WHERE id={$id}");

// 取得所有跟帖 pid=$id
$sql = "SELECT * FROM msgs WHERE pid={$id} ORDER BY sd DESC, user";
// 取PDO数据对象
$resp = $pdo->query($sql);
// 取数据（关联数组）
$reply = $resp->fetchAll(PDO::FETCH_ASSOC);

// 转换为 JSON 格式并输出（到前台）
echo json_encode(array_merge($data, $reply));