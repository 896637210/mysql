<?php
session_start();
require_once "dbc.php";

$res = [
    "error" => true,
    "text" => "失败！"
];
if (isset($_REQUEST["title"], $_REQUEST["msg"], $_SESSION["USER"])) {
    $user = $_SESSION["USER"];
    $title = trim($_REQUEST["title"]);
    $msg = trim($_REQUEST["msg"]);

    // 保存新贴
    $sql = "INSERT INTO msgs (user, title, msg) VALUES ('{$user}', '{$title}', '{$msg}')";
    if ($pdo->exec($sql)) {
        $res["error"] = false;
        $res["text"] = "成功！";
    }
}

echo json_encode($res);
