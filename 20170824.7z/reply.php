<?php
session_start();
require_once "dbc.php";

$res = [
    "error" => true,
    "text" => "失败！"
];
if (isset($_REQUEST["pid"], $_REQUEST["msg"], $_SESSION["USER"])) {
    $user = $_SESSION["USER"];
    $pid = trim($_REQUEST["pid"]);
    $msg = trim($_REQUEST["msg"]);
    // 保存跟贴 pid
    if ($msg != "") {
        $sql = "INSERT INTO msgs (pid, user, title, msg) VALUES ({$pid}, '{$user}', ' ', '{$msg}')";
        if ($pdo->exec($sql)) {
            $res["error"] = false;
            $res["text"] = "成功！";
        }
    }
}

echo json_encode($res);
