<?php

# PHP 制作图片 需要引擎（gd：GraphicDriver）：gd2
// $img = imagecreate(200, 100); // 256色图片
$img = imagecreatetruecolor(200, 200); // 真彩图片 65536色

# 设定颜色 imagecolorallocate(图片对象变量, 红色值, 绿色值, 蓝色值)
$red = imagecolorallocate($img, 255, 0, 0);
$green = imagecolorallocate($img, 0, 255, 0);
$blue = imagecolorallocate($img, 0, 0, 255);
$yellow = imagecolorallocate($img, 255, 255, 0);
$black = imagecolorallocate($img, 0, 0, 0);
$white = imagecolorallocate($img, 255, 255, 255); // R，G，B

# 填背景色 imagefill
imagefill($img, 0, 0, $black);

# 画线 imageline(image, x1, y1, x2, $y2, color)
// imageline($img, 0,0, 199,199, $red);

# 输出文字 imagestring(图片对象, 文字大小, x坐标, y坐标, 文字字符串, 文字颜色)
# 输出文字 imagettftext(image, size, angle, x, y, color, font, text)
$font = "C:\\Windows\\Fonts\\simhei.ttf";
$text = "欢迎光临";
imagettftext($img, 36, rand(0, 30), 0, rand(36, 200), $green, $font, $text);
// imagestring($img, 6, 10, 60,  'size 6 Text String', $text_color);
// imagestring($img, 3, 10, 30,  'size 3 Text String', $text_color);
// imagestring($img, 1, 10, 10,  'size 1 Text String', $text_color);

// 设置图片输出格式 image/jpeg, png, gif, bmp, ...
header('Content-Type: image/png');

# PHP 动态输出图片
imagepng($img);

# 删除内存中的图片（对象）
imagedestroy($img);
