<?php
$file = "img/ionic.png";
$data = file_get_contents($file);
$code = base64_encode($data);
$head = "data:image/png; base64, ";
?>
<textarea cols="100" rows="20"><?=$head?><?=$code?></textarea>