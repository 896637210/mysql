<?php
// require_once "tool.php";
$path = "../img/";
if (isset($_REQUEST["img"])){
    $file = $path . trim($_REQUEST["img"]);
    # 判断图片类型
    $info = pathinfo($file);
    $type = $info["extension"];
    # 取图片信息
    $info = getimagesize($file);
    // [0]width [1]height
    // [2]type:
    // 1=GIF, 2=JPEG, 3=PNG, 4=SWF, 5=SWC, 6=PSD, 7=TIFF, 8=BMP, 9=IFF,
    // 10=JP2, 11=JPX, 12=JB2, 13=JPC, 14=XBM, 15=WBMP
    // msg($info);
    // echo $file;
    // exit;
    # 依据类型加载图片
    // switch($type){
    switch($info[2]){
        // case "jpeg":
        // case "jpg":
        case 2:
            $img = imagecreatefromjpeg($file);
            break;
        // case "png":
        case 3:
            $img = imagecreatefrompng($file);
            break;
        // case "gif":
        case 1:
            $img = imagecreatefromgif($file);
        default:
            exit;
    }
    # 做水印
    $white = imagecolorallocate($img, 192, 192, 192);
    imageline($img, 0, 0, $info[0], $info[1], $white);
    imageline($img, $info[0], 0, 0, $info[1], $white);
    // $font = "C:\\Windows\\Fonts\\simyou.ttf";
    // for($i = 0; $i < 20; $i++){
    //     for($j = 0; $j < 40; $j++){
    //         imagettftext($img, 10, 30, 36 * $j, 48 * $i, $white, $font, "水印");
    //     }
    // }
    # 输出图片
    header('Content-Type: image/png');
    imagepng($img);
    # 释放内存
    imagedestroy($img);
}