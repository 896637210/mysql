<?php
require_once "tool.php";

$n = rand(1000, 9999);
msg($n);

$a = [10, 200, 3000, "A"];
msg($a);
shuffle($a);
shuffle($a);
msg($a);